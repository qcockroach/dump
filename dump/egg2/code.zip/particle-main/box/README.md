### box
It is alternative for weak machines. You can install Linux on USB stick and then use this command at the begining of your session. It'll make necessary data links and device setup usitable for you. BTW you can switch to Persistence mode and don't care about box. But I'm in circumstances where I've Pentium CPU and 3.8 Gb RAM, so switch to Persistence mode significantly slows my performance. Most part of my life I deal with weak, damaged and old machines. That's way we go.
<br/><br/>

***Options*** <br/>
* init box environment <br/>
* set box environment (default) <br/>
* free box RAM memory <br/>
* user utils: conn, send, pkgs, halt
<br/>
