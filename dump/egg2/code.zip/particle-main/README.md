# particle

There're projects that have one-two files of source code. Just utils written by me
and for my own purpose. If anyone needs them too, I have notging against. 
BUT I wrote them for me and for my own use only. No external effect at all.
