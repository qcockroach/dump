#include <ctype.h>
#include <stdlib.h>
#include "input.h"
#include "engine.h"



int in_chknum(const char *s)
{
	if (s == NULL)
		INPUT_NULL;

	while (*s != '\0')
		if (!isdigit(*s++))
			return INPUT_ERROR_INT;
		
	return	INPUT_OK;
}

int in_chkstr(const char *s)
{
	const char *p = s;

	if (s == NULL)
		INPUT_NULL;

	if (isdigit(*p++)) {
		fprintf(stderr, "ERROR: string can't start with number\n");
		return INPUT_ERROR_STR;
	}

	while (*p) {
		if (!(isalnum(*p) || *p == '_') ) {
			return INPUT_ERROR_STR;
		}
		p++;
	}

	return	INPUT_OK;
}

int in_getnum(int *num)
{
	char buffer[MAX_NAME_LENGTH], *p = buffer;
	int flag;
	size_t size;

	getline(&p, &size, stdin);
	in_cutn(p);
	if ( (flag = in_chknum(p) ) != INPUT_OK)
		return flag;

	*num = atoi(p);
	return DB_OK;
}

int in_getword(char *s)
{
	int c, flag, size = 0;
	char *p = s;

	while ((c = getchar()) != EOF && c != '\n' && size < MAX_NAME_LENGTH) {
		*p++ = c;
		size++;
	}
	*p = '\0';

	if ((flag = in_chkstr(s)) != INPUT_OK)
		return flag;

	return INPUT_OK;
}

int in_getstr(char *s)
{
	int c, size = 0;
	while ((c = getchar()) != EOF && c != '\n' && size < MAX_NAME_LENGTH) {
		*s++ = c;
		size++;
	}
	*s = '\0';

	return 0;
}

void in_cutn(char *s)
{
	char *p = s;

	while (*p && *p != EOF) {
		if (*p == '\n')
			*p = '\0';
		p++;
	}
}

int is_word(const char *s)
{
	if (isdigit(*s))
		return 0;

	while (*s) {
		if (! (isalnum(*s) || *s == '_') )
			return 0;
		s++;
	}
	return 1;
}

int is_num(const char *s)
{
	while (*s)
		if (!isdigit(*s++))
			return 0;
	return 1;
}

