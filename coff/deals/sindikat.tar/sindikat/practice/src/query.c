#include <string.h>

#include "query.h"



char *table_columns[] = 
{
	"name",
	"number",
	"size",
	"capacity",
	"audit_type",
	"board_type"
};

char *query_keywords[] = 
{
	"select",
	"from",
	"table",
	"where",
	"and",
};

char *query_operators[] =
{
	"=",
	"<",
	">"
};


int qry_getcolumn(char *fact, struct param_t *dst, int *idx)
{
	char *tok;

	if ((tok = strtok(fact, Q_DELIM)) == NULL) {
		printf("Syntax error: excpected column label\n");
		return -1;
	}

	int i;
	for (i = 0; i < T_SIZE; i++)
		if (strcmp(tok, table_columns[i]) == 0)
			break;

	if (i == T_SIZE) {
		printf("Syntax error: Invalid column label\n");
		return -1;
	}

	*idx = i;
	dst[i].column = USED;
	return 0;
}


int qry_getop(char *term, struct param_t *dst, int idx)
{
	char *tok;

	if ((tok = strtok(term, Q_DELIM)) == NULL) {
		printf("Syntax error: excpected operator\n");
		return -1;
	}

	int i;
	for (i = 0; i < OP_SIZE; i++)
		if (strcmp(tok, query_operators[i]) == 0)
			break;

	if (i == OP_SIZE) {
		printf("Syntax error: Invalid compare operator %d\n", i);
		return -1;
	}

	printf("[+] op: %d\n", i);
	dst[i].op = i;
	return 0;
}

int qry_getvalue(char *term, struct param_t *dst, int idx)
{
	char *tok;

	if ((tok = strtok(term, Q_DELIM)) == NULL) {
		printf("Syntax error: excpected value\n");
		return -1;
	}

	strcpy(dst[idx].value, tok);
	return 0;
}

int qry_getbop(char *query, struct param_t *dst, int idx)
{
	char *tok;

	if ((tok = strtok(query, Q_DELIM)) == NULL) {
		dst->bound = -1;
		return 1;
	}

	if (strcmp(tok, "and") == 0) {
		dst[idx].bound = 0;
	}
	else {
		printf("Syntax error: Invalid bound operator %s\n", tok);
		return -1;
	}

	return 0;
}

int qry_getexpr(char *query, struct param_t *param, int *count)
{
	int i, flag;
	for (i = 0; i < 6; i++)
		param[i].column = UNUSED;
	

	/* start */
	strtok(query, Q_DELIM);
	int idx;
	for (i = 0; i < 6; i++) {
		if (qry_getcolumn(NULL, param, &i) != 0)
			return -1;

		if (qry_getop(NULL, param, i) != 0)
			return -1;

		if (qry_getvalue(NULL, param, i) != 0)
			return -1;

		flag = qry_getbop(NULL, param, i);


		if (flag == -1){
			return -1;
		}
		else if (flag == 1){
			i++;
			break;
		}

	}

	*count = i ;
	return 0;
}

int qry_show(struct param_t *param, int count)
{
	printf("count: %d\n", count);
	for (int i = 0; i < count; i++) {
		printf("[*] used: %d\n", param[i].column);
		printf("[*] oper: %d\n", param[i].op);
		printf("[*] val : %s\n", param[i].value);
		printf("[*] bop : %d\n\n", param[i].bound);
	}
}
