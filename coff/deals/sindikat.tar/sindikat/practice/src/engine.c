#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>

#include "engine.h"
#include "query.h"
#include "input.h"


static struct auditorium list[MAX_ROW_COUNT];
static int row_count;

static int db_new_row(int idx);



void error_handling(int flag)
{
	switch(flag) {
		case DB_OK:
			break;

		case DB_INVALID_CMD:
			fprintf(stderr, "WARNING: invalid command\n");
			break;

		case DB_ROW_OVERFLOW:
			fprintf(stderr, "ERROR  : Table is full\n");
			break;

		case DB_ROW_UNDERFLOW:
			fprintf(stderr, "ERROR  : Table is empty\n");
			break;
	}
}

static int check_row(int row)
{
	if (row < 0)
		return DB_ROW_UNDERFLOW;

	if (row > row_count)
		return DB_ROW_OVERFLOW;

	return DB_OK;
}



void db_init()
{
	int i = 0;
	for (i = 0; i < MAX_ROW_COUNT; i++)
		list[i].mark = FREE;
}

int db_add_row()
{
	int i;
	for (i = 0; i < MAX_ROW_COUNT; i++)
		if (list[i].mark == FREE)
			break;

	if (i == MAX_ROW_COUNT) {
		fprintf(stderr, "WARNING: db overflow\n");
		return DB_ROW_OVERFLOW;
	}

	return db_new_row(i);
}

static int db_new_row(int idx)
{
	int size, num, flag, i;
	struct auditorium row;
	char buffer[MAX_NAME_LENGTH], *p = buffer;


	printf("corpus name       : ");
	if ((flag = in_getword(p) != INPUT_OK))
		return flag;
	strcpy(row.name, p);


	printf("auditorium number : ");
	if ( (flag = in_getnum(&row.number) ) != INPUT_OK)
		return flag;


	printf("auditorium size   : ");
	if ( (flag = in_getnum(&row.size) ) != INPUT_OK)
		return flag;


	printf("auditorium capac  : ");
	if ( (flag = in_getnum(&row.capacity) ) != INPUT_OK)
		return flag;


	/* (1 - multimedia, 0 - casual) */
audit_label:
	printf("auditorium type   : ");
	if ( (flag = in_getnum(&num) ) != INPUT_OK)
		return flag;

	if (num > 2) {
		fprintf(stderr, "WARNING: audit_types: 1 or 0\n");
		goto audit_label;
	}
	row.audit_type = num;


	/* 1 - oxcid, 0 - marker */
board_label:
	printf("board type        : ");
	if ( (flag = in_getnum(&num) ) != INPUT_OK)
		return flag;
	if (num > 2) {
		fprintf(stderr, "WARNING: board_types: 1 or 0\n");
		goto board_label;
	}
	row.board_type = num;


	row_count++;
	row.mark = BUSY;
	memcpy(&list[idx], &row, sizeof(row));

	return INPUT_OK;
}

int db_chg_row(int row)
{
	printf("1. name\t\t2. number\t\t3. size\n");
	printf("4. capacity\t5. audit_type\t\t6. board_type\n>_ ");

	int num, flag;
	char buffer[MAX_NAME_LENGTH], *p = buffer;

	/* check out if we have any row */
	if (row_count == 0) {
		return DB_OK;
	}


	in_getnum_label:
	if ((flag = in_getnum(&num)) != DB_OK)
		return flag;


	if (!(num >= 1 && num <= 6)) {
		printf("WARNING: invalid column. Try again\n");
		goto in_getnum_label;
	}

	switch(num) {
		case 1:
			printf("name  : ");
			if ((flag = in_getword(p)) != DB_OK)
				return flag;
			memcpy(&list[row].name, p, MAX_NAME_LENGTH);
			break;

		case 2:
			printf("number: ");
			if ((flag = in_getnum(&list[row].number)) != DB_OK)
				return flag;
			break;

		case 3:
			printf("size  : ");
			if ((flag = in_getnum(&list[row].size)) != DB_OK)
				return flag;
			break;

		case 4:
			printf("capacity: ");
			if ((flag = in_getnum(&list[row].capacity)) != DB_OK)
				return flag;
			break;

		case 5:
			printf("audit_type: ");
			if ((flag = in_getnum(&num)) != DB_OK)
				return flag;
			if (num > 2) {
				fprintf(stderr, "WARNING: audit types: 1 or 0\n");
				return -1;
			}
			break;

		case 6:
			printf("board_type: ");
			if ((flag = in_getnum(&num)) != DB_OK)
				return flag;
			if (num > 2) {
				fprintf(stderr, "WARNING: board types: 1 or 0\n");
				return -1;
			}
			break;

		default:
			printf("WARNING: invalid column\n");
			return 0;
	}

	return DB_OK;
}

int db_del_row(int row)
{
	int flag;
	if ((flag = check_row(row)) != DB_OK)
		return flag;

	list[row].mark = FREE;
	row_count--;
	return DB_OK;
}











/*
SELECT * FROM table WHERE 
name = newname and size = 100
*/






/* !! Cannot handle `or' bound operator  */
int db_query()
{
	if (row_count == 0) {
		printf("WARNING: table is empty\n");
		return DB_OK;
	}


	struct param_t param[6], cmprow[6];
	struct pair_t pair[6];
	char query[QRY_MAX_LEN], *p = query;
	int count = 0;

	for (int i = 0; i < 6; i++)
		param[i].column = UNUSED;

	printf("SELECT * FROM TABLE ");
	if (in_getstr(p) != 0) {
		printf("ERROR: reading query\n");
		return -1;
	}

	qry_getexpr(query, param, &count);
	//qry_show(param, count);



	/* perform query */



	int num, op, prev, flag = -1;
	for (int i = 0; i < row_count; i++) {
		prev = flag;

		/* compare name */
		if (param[0].column == USED) {
			if (strcmp(param[0].value, list[i].name) == 0) {
				pair[0].flag = 1;
				pair[0].bop  = param[0].bound;
			}
			else {
				printf("[+] name is wrong [%s] : [%s]\n", list[i].name, param[0].value);
				pair[0].flag = 0;
			}

			printf("op  : %d\n", param[0].op);
			printf("flag: %d\n", pair[0].flag);
			printf("bop : %d\n", pair[0].bop);
			printf("\n");
		}


		/* !! Note: name is skipped */
		for (int j = 1; j < 6; ++j) {
			if (param[j].column == UNUSED) {
				continue;
			}

			num = atoi(param[j].value);
			op  = param[j].op;

			switch(op) {
				case QRY_EQ:
					printf("[+] case QRY_EQ\n");
					if (list[i].number == num) {
						pair[j].flag = 1;
						pair[j].bop  = param[j].bound;
						printf("[+] number is right [%d] : [%d]\n", list[i].number, num);
					}
					else {
						printf("[+] number is wrong [%d] : [%d]\n", list[i].number, num);
						pair[j].flag = 0;
					}
				break;

				case QRY_LT:
					printf("[+] case QRY_LT\n");
					if (list[i].number < num) {
						pair[j].flag = 1;
						pair[j].bop  = param[j].bound;
					}
					else
						pair[j].flag = 0;
				break;

				case QRY_GT:
					printf("[+] case QRY_GT\n");
					if (list[i].number > num) {
						pair[j].flag = 1;
						pair[j].bop  = param[j].bound;
					}
					else
						pair[j].flag = 0;
				break;

				default:
					printf("Syntax error: Invalid operator %d\n", op);
					break;
			}


			printf("op  : %d\n", param[j].op);
			printf("flag: %d\n", pair[j].flag);
			printf("bop : %d\n", pair[j].bop);
			printf("\n");
		}
	}



	
	printf("done\n");	
	return DB_OK;
}


/*
SELECT * FROM table WHERE 
- name = newname and number < 324 or size > 100
- number = 1
*/

int db_show_table()
{
	if (row_count == 0)
		return DB_OK;

	int i;
	printf("NAME\t\tNUMBER\tSIZE\tCAPAC\tBTYPE\tATYPE\n");
	for (i = 0; i < row_count; i++) {
		printf("%s\t\t %d\t %d\t %d\t %d\t %d\n", 
			list[i].name,
			list[i].number,
			list[i].size,
			list[i].capacity,
			list[i].board_type,
			list[i].audit_type);
	}

	return DB_OK;
}








int db_interface()
{
	printf("1. Add new row\n");
	printf("2. Change row\n");
	printf("3. Delete row\n");
	printf("4. Make query\n");
	printf("5. Show table\n");
	printf("0. Exit\n");




	int cmd, flag, row;
	char buffer[MAX_NAME_LENGTH], *p = buffer;


	db_init();
	while (1) {
		printf("\n> ");
		if ((flag = in_getnum(&cmd)) != DB_OK)
			return flag;

		switch (cmd){
			case 1:
				flag = db_add_row(row);
				break;

			case 2:
				printf("row: ");
				if ((flag = in_getnum(&row)) != DB_OK)
					return flag;

				flag = db_chg_row(row);
				break;

			case 3:
				printf("row: ");
				if ((flag = in_getnum(&row)) != DB_OK)
					return flag;

				flag = db_del_row(row);
				break;

			case 4:
				flag = db_query();
				break;

			case 5:
				flag = db_show_table(row);
				break;

			case 0:
				/* exit */
				return 0;

			default:
				flag = DB_INVALID_CMD;
				break;
		}

		/* Handing return flag value */
		error_handling(flag);
	} 
}













