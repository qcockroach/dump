#ifndef __INPUT_H
#define __INPUT_H

enum INPUT_ERROR_TYPE
{
	INPUT_OK,
	INPUT_ERROR_STR,
	INPUT_ERROR_INT,
	INPUT_NULL
};


int  in_chkstr(const char *s);
int  in_chknum(const char *s);
int  in_getnum(int *num);
int  in_getstr(char *s);
int  in_getword(char *s);
void in_cutn(char *s);

int is_word(const char *s);
int is_num(const char *s);

#endif