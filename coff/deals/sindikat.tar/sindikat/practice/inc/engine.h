#ifndef __DB_ENGINE_H
#define __DB_ENGINE_H

#include <stdio.h>

#define MAX_ROW_COUNT 		7
#define MAX_NAME_LENGTH		50



#define FREE 				0
#define BUSY 				1
struct auditorium
{
	char name[MAX_NAME_LENGTH];
	int number;
	size_t size;
	size_t capacity;
	char audit_type;
	char board_type;
	char mark;
};

enum DB_ERROR_TYPE
{
	DB_OK,
	DB_ROW_OVERFLOW,
	DB_ROW_UNDERFLOW,
	DB_INVALID_CMD = -1
};

void db_init();
int db_interface();


int db_add_row();
int db_chg_row(int row);
int db_del_row(int row);
int db_query();
int db_show_table();



#endif