#ifndef __DEV_H
#define __DEV_H

#include <stdint.h>
#include "engine.h"

#define MAX_ROW_COUNT 		20 /* max код-во рядов в файле */


/* 
	+49 name length
	+10 digits for each number (x3)
	+1  digit  for each type   (x2)

	+5 space padding symbols 
	+1 newline
	--------------

	ROW_SIZE = 87;
 */

extern const int ROW_SIZE;


/* 
	открыть и закрыть файл
 */
int dev_open(const char *fname, const char *mode);
int dev_close();

/* 
	чтение и запись в файл определенной строки
 */
int dev_row_count();
int dev_delete_row(int idx);
int dev_get_row(int idx, struct auditorium *row);
int dev_put_row(int idx, struct auditorium *row);


struct storage_dev_t
{
	int (*read)(void *buffer);
	int (*write)(const void *buffer);
	int (*seek)(uint32_t offset);
};





#endif