#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dev.h"


const int ROW_SIZE = 87;
static FILE *image = NULL;
static char fname[20];


int dev_row_count()
{
	char row[ROW_SIZE], *p = row;
	int  count = 0;

	while (fread(p, 1, ROW_SIZE, image) == ROW_SIZE)
		count++;

	if (count > MAX_ROW_COUNT) {
		fprintf(stderr, "[~] WARNING: Table contains more row than `db' can load\n");
	}

	/* Возврат указателя на начало */
	dev.seek(0);
	return count;
}


/*
	!! после каждого удаления нежно выходть из программы
	
	процесс:
		* переписывает все нужные строки в отдельный файл
		* удаляем наш файл и
		* переименовываем новый
	теперь у нас все строки кроме ненужной


- number > 1 and capacity > 1 and audit_type = 1 and board_type = 0
- number > 1 and capacity > 1 and audit_type = 1

*/
int dev_delete_row(int idx)
{
	char *fname_copy = "data/table.cp";
	FILE *f2 = fopen(fname_copy, "w");

	if (!f2) {
		printf("ERROR: open file in write mode: %s\n", fname_copy);
		return -1;
	}
	int cutter = 0, c;


	if (idx == 0) {
		while ((c = getc(image)) != EOF) {
			if (c == '\n') {
				cutter++;
				break;
			}
		}
	}

	while ((c = getc(image)) != EOF) {
		if (c == '\n')
			cutter++;

		if (cutter != idx) {
			putc(c, f2);
		}
	}
	fclose(f2);

	remove(fname);
	rename(fname_copy, fname);

	/* update file position */
	image = freopen(fname, "r+", image);
	return 0;
}

int dev_get_row(int idx, struct auditorium *row)
{
	char line[ROW_SIZE], *p = line;

	dev.seek(idx * ROW_SIZE);

	dev.read(p);
	sscanf(p, "%s %d %d %d %d %d",
		(row->name),
		&(row->number),
		&(row->size),
		&(row->capacity),
		&(row->audit_type),
		&(row->board_type) );

	return 0;
}

int dev_put_row(int idx, struct auditorium *row)
{
	char str_row[ROW_SIZE], line[ROW_SIZE];
	int  pos;

	/* row with data */
	sprintf(str_row, "%s %d %d %d %d %d",
		row->name,
		row->number,
		row->size,
		row->capacity,
		row->audit_type,
		row->board_type);


	/* padding */
	int pad_size = ROW_SIZE - strlen(str_row) - 1;
	char padding[pad_size];
	memset(padding, '.', pad_size);


	/* fulfill line */
	sprintf(line, "%s%s", str_row, padding);

	/* truncate dump byites */
	line[ROW_SIZE-1] = '\n';
	line[ROW_SIZE]   = '\0';


	pos = idx * ROW_SIZE;
	dev.seek(pos);

	return dev.write(line);
}

int dev_open(const char *_fname, const char *mode)
{
	if (_fname == NULL) {
		printf("dev_open: Cannot open image with null fname\n");
		return -1;
	}

	if ((image = fopen(_fname, mode)) == NULL) {
		if ((image = fopen(_fname, "w+")) == NULL)
			printf("dev_open: Could not open file\n");

		return -1;
	}

	strcpy(fname, _fname);
	return 0;
}

int dev_read(void *buffer)
{
	char *p;
	if (buffer == NULL) {
		printf("dev_read: Cannot read with null buffer string\n");
		return -1;
	}

	if (fread(buffer, 1, ROW_SIZE, image) != ROW_SIZE) {
		printf("dev_read: [!] Error while reading row\n");
		return -1;
	}

	/* truncate dump bytes */
	p = (char*)buffer;
	p[ROW_SIZE] = '\0';

	return 0;
}

int dev_write(const void *buffer)
{
	if (buffer == NULL) {
		printf("dev_write: Cannot write from null buffer string\n");
		return -1;
	}

	if (fwrite(buffer, 1, ROW_SIZE, image) != ROW_SIZE) {
		printf("[!] Error while writing %u bytes into row\n", ROW_SIZE);
		return -1;
	}

	return 0;
}

int dev_seek(uint32_t offset)
{
	return fseek(image, offset, SEEK_SET);
}

int dev_close()
{
	return fclose(image);
}


struct storage_dev_t dev = {
	dev_read,
	dev_write,
	dev_seek
};


