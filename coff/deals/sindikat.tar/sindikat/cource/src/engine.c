#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>

#include "query.h"
#include "dev.h"
#include "input.h"
#include "engine.h"


const int TEST_MODE = 0;
static int row_count;


/*
	Проверка индекса строки в БД
	+ существует
	+ менше или равно общего числа в таблице
*/
static int check_row(int idx)
{
	if (idx < 0)
		return DB_ROW_UNDERFLOW;

	if (idx > row_count) {
		printf("[+] %d : %d\n", idx, row_count);
		return DB_ROW_OVERFLOW;
	}

	return DB_OK;
}

void db_init()
{
	dev_open("data/table.db", "r+");

	/* init row_count */
	row_count = dev_row_count();
	printf("[+] row_count: %d\n", row_count);
}

int db_add_row()
{
	int num, flag;
	struct auditorium row;
	char buffer[MAX_NAME_LENGTH], *p = buffer;


	if (TEST_MODE) printf("\n");
label_name:
	printf("    corpus name       : ");
	if ((flag = in_getword(p) != INPUT_OK))
		goto label_name;
	strcpy(row.name, p);
	
	if (TEST_MODE) printf("\n");

label_number:
	printf("    auditorium number : ");
	if ( (flag = in_getnum(&row.number) ) != INPUT_OK)
		goto label_number;
	if (TEST_MODE) printf("\n");


label_size:
	printf("    auditorium size   : ");
	if ( (flag = in_getnum(&row.size) ) != INPUT_OK)
		goto label_size;
	if (TEST_MODE) printf("\n");


label_capac:
	printf("    auditorium capac  : ");
	if ( (flag = in_getnum(&row.capacity) ) != INPUT_OK)
		goto label_capac;
	if (TEST_MODE) printf("\n");


/* (1 - multimedia, 0 - casual) */
label_audit:
	printf("    auditorium type   : ");
	if ( (flag = in_getnum(&num) ) != INPUT_OK)
		goto label_audit;

	if (num > 1) {
		fprintf(stderr, "[~] WARNING: audit_types: 1 or 0\n");
		goto label_audit;
	}
	row.audit_type = num;
	if (TEST_MODE) printf("\n");


/* 1 - oxcid, 0 - marker */
label_board:
	printf("    board type        : ");
	if ( (flag = in_getnum(&num) ) != INPUT_OK)
		return flag;
	if (num > 1) {
		fprintf(stderr, "[~] WARNING: board_types: 1 or 0\n");
		goto label_board;
	}
	row.board_type = num;
	if (TEST_MODE) printf("\n");


	row_count++;
	dev_put_row(row_count - 1, &row);
	return 0;
}

int db_chg_row(int idx)
{
	printf("1. name\t\t2. number\t\t3. size\n");
	printf("4. capacity\t5. audit_type\t\t6. board_type\n");

	int  num, flag, column;
	char buffer[MAX_NAME_LENGTH], *p = buffer;
	struct auditorium row;


	/* check out if we have any row */
	if (row_count == 0)
		return DB_OK;

	/* Prevent attemt to access non-existed row */
	if (idx > row_count) {
		printf("[!] ERROR: Invalid row index [%d]\n", idx);
		return DB_INVALID_CMD;
	}

	dev_get_row(idx, &row);


in_getnum_label:
	printf(">_ ");
	if ((flag = in_getnum(&column)) != DB_OK
		|| !(column >= 1 && column <= 6)) {
		fprintf(stderr, "[~] WARNING: Invalid row index [%d]\n", column);
		goto in_getnum_label;
	}

	switch(column) {
		case 1:
			printf("name  : ");
			if ((flag = in_getword(p)) != DB_OK)
				return flag;
			memcpy(row.name, p, MAX_NAME_LENGTH);
			break;

		case 2:
			printf("number: ");
			if ((flag = in_getnum(&row.number)) != DB_OK)
				return flag;
			break;

		case 3:
			printf("size  : ");
			if ((flag = in_getnum(&row.size)) != DB_OK)
				return flag;
			break;

		case 4:
			printf("capacity: ");
			if ((flag = in_getnum(&row.capacity)) != DB_OK)
				return flag;
			break;

		case 5:
			printf("audit_type: ");
			if ((flag = in_getnum(&num)) != DB_OK)
				return flag;
			if (num > 2) {
				fprintf(stderr, "WARNING: audit types: 1 or 0\n");
				return -1;
			}
			row.audit_type = num;
			break;

		case 6:
			printf("board_type: ");
			if ((flag = in_getnum(&num)) != DB_OK)
				return flag;
			if (num > 2) {
				fprintf(stderr, "WARNING: board types: 1 or 0\n");
				return -1;
			}
			row.board_type = num;
			break;

		default:
			printf("WARNING: invalid column\n");
			return 0;
	}

	dev_put_row(idx, &row);
	return 0;
}

int db_del_row(int idx)
{
	int flag;
	if ((flag = check_row(idx)) != DB_OK) {
		printf("[~] WARNING No such row: %d\n", idx);
		return flag;
	}
	dev_delete_row(idx);

	row_count--;
	return DB_OK;
}


/*
	!! Запрос должен обязательно начинатся с дефиса/минуса, пробел и
		только потом затрос
	
	exp:
		- name = jack and size < 10
		- number > 10 and board_type = 1
		- size > 100

	ONLY select query with
	`and' bin operation 
*/
int db_query()
{
	char query[200], *p = query;

	/* get query string */
	printf("[*] SELECT * FROM TABLE ");
	in_getquery(p);

	/* send query string for parsing */
	struct param_t param[6];
	memset(param, 0, sizeof(param));
	if (qry_parse_query(p, param) == -1) {
		fprintf(stderr, "[-] ERROR: Invalid query\n");
		return -1;
	}

	/* perform query */
	return qry_run_query(param, row_count);
}


int db_show_table()
{
	struct auditorium row;
	int i = 0;

	printf("\nNAME            NUMBER      SIZE        CAPAC       ATYPE  BTYPE\n");
	for ( ; i < row_count; i++) {
		dev_get_row(i, &row);
		show_row(&row);
	}

	return dev.seek(0);
}



int show_row(struct auditorium *row)
{
	char number[15],
		 size[15],
		 capacity[15],
		 board_type[2],
		 audit_type[2];

	sprintf(number, "%d", row->number);
	sprintf(size, "%d", row->size);
	sprintf(capacity, "%d", row->capacity);
	sprintf(board_type, "%d", row->board_type);
	sprintf(audit_type, "%d", row->audit_type);

	
	printf("%-*s %-*s %-*s %-*s %-*s %-*s\n", 
		15, row->name,
		11, number,
		11, size,
		11, capacity,
		6, audit_type,
		2, board_type);

	return 0;
}

int db_exit()
{
	dev_close();
	return 0;
}


/*
	add_row
	chn_row
	del_row
	query
	exit
   *show_row
*/
int db_interface()
{
	printf("1. Add new row\n");
	printf("2. Change row\n");
	printf("3. Delete row\n");
	printf("4. Make query\n");
	printf("5. Show table\n");
	printf("0. Exit\n");
	int cmd, flag, row;



	db_init();
	while (1) {
		printf("\n> ");
		if ((flag = in_getnum(&cmd)) != DB_OK)
			return flag;

		switch (cmd){
			case 1:
				flag = db_add_row(row);
				break;

			case 2:
				printf("row: ");
				if ((flag = in_getnum(&row)) != DB_OK)
					return flag;

				flag = db_chg_row(row);
				break;

			case 3:
				printf("row: ");
				if ((flag = in_getnum(&row)) != DB_OK)
					return flag;

				flag = db_del_row(row);
				break;

			case 4:
				flag = db_query();
				break;

			case 5:
				flag = db_show_table(row);
				break;

			case 0:
				return db_exit();

			default:
				flag = DB_INVALID_CMD;
				break;
		}

		/* Handing return flag value */
		//error_handling(flag);
	} 
}


