#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>

#include <wchar.h>
#include <locale.h>


#include "engine.h"
#include "query.h"
#include "input.h"


struct auditorium list[MAX_ROW_COUNT];
static int row_count;

static int db_new_row(int idx);



void error_handling(int flag)
{
	switch(flag) {
		case DB_OK:
			break;

		case DB_INVALID_CMD:
			fprintf(stderr, "[~] WARNING: invalid command\n");
			break;

		case DB_ROW_OVERFLOW:
			fprintf(stderr, "[!] ERROR  : Table is full\n");
			break;

		case DB_ROW_UNDERFLOW:
			fprintf(stderr, "[!] ERROR  : Table is empty\n");
			break;
	}
}

static int check_row(int row)
{
	if (row < 0)
		return DB_ROW_UNDERFLOW;

	if (row > row_count)
		return DB_ROW_OVERFLOW;

	return DB_OK;
}



void db_init()
{
	int i = 0;
	for (i = 0; i < MAX_ROW_COUNT; i++)
		list[i].mark = FREE;
}

int db_add_row()
{
	int i;
	for (i = 0; i < MAX_ROW_COUNT; i++)
		if (list[i].mark == FREE)
			break;

	if (i == MAX_ROW_COUNT) {
		fprintf(stderr, "WARNING: db overflow\n");
		return DB_ROW_OVERFLOW;
	}

	return db_new_row(i);
}

static int db_new_row(int idx)
{
	int num, flag;
	struct auditorium row;
	char buffer[MAX_NAME_LENGTH], *p = buffer;

label_name:
	printf("corpus name       : ");
	if ((flag = in_getword(p) != INPUT_OK))
		goto label_name;
	strcpy(row.name, p);


label_number:
	printf("auditorium number : ");
	if ( (flag = in_getnum(&row.number) ) != INPUT_OK)
		goto label_number;


label_size:
	printf("auditorium size   : ");
	if ( (flag = in_getnum(&row.size) ) != INPUT_OK)
		goto label_size;


label_capacity:
	printf("auditorium capac  : ");
	if ( (flag = in_getnum(&row.capacity) ) != INPUT_OK)
		goto label_capacity;


	/* (1 - multimedia, 0 - casual) */
label_audit:
	printf("auditorium type   : ");
	if ( (flag = in_getnum(&num) ) != INPUT_OK)
		goto label_audit;

	if (num > 1) {
		fprintf(stderr, "[~] WARNING: audit_types: 1 or 0\n");
		goto label_audit;
	}
	row.audit_type = num;


	/* 1 - oxcid, 0 - marker */
label_board:
	printf("board type        : ");
	if ( (flag = in_getnum(&num) ) != INPUT_OK)
		goto label_board;

	if (num > 1) {
		fprintf(stderr, "[~] WARNING: board_types: 1 or 0\n");
		goto label_board;
	}
	row.board_type = num;


	row_count++;
	row.mark = BUSY;
	memcpy(&list[idx], &row, sizeof(row));

	return INPUT_OK;
}

int db_chg_row(int row)
{
	printf("1. name\t\t2. number\t\t3. size\n");
	printf("4. capacity\t5. audit_type\t\t6. board_type\n");

	int num, flag;
	char buffer[MAX_NAME_LENGTH], *p = buffer;

	/* check out if we have any row */
	if (row_count == 0)
		return DB_OK;

	/* Prevent attemt to access non-existed row */
	if (row > row_count) {
		printf("[!] ERROR: Invalid row index [%d]\n", row);
		return DB_INVALID_CMD;
	}

in_getnum_label:
	printf(">_ ");
	if ((flag = in_getnum(&num)) != DB_OK
		|| !(num >= 1 && num <= 6)) {
		printf("[~] WARNING: invalid column. Try again\n");
		goto in_getnum_label;
	}

	switch(num) {
		case 1:
			printf("name  : ");
			if ((flag = in_getword(p)) != DB_OK)
				return flag;
			memcpy(&list[row].name, p, MAX_NAME_LENGTH);
			break;

		case 2:
			printf("number: ");
			if ((flag = in_getnum(&list[row].number)) != DB_OK)
				return flag;
			break;

		case 3:
			printf("size  : ");
			if ((flag = in_getnum(&list[row].size)) != DB_OK)
				return flag;
			break;

		case 4:
			printf("capacity: ");
			if ((flag = in_getnum(&list[row].capacity)) != DB_OK)
				return flag;
			break;

		case 5:
			printf("audit_type: ");
			if ((flag = in_getnum(&num)) != DB_OK)
				return flag;
			if (num > 1) {
				fprintf(stderr, "WARNING: audit types: 1 or 0\n");
				return -1;
			}
			list[row].audit_type = num;
			break;

		case 6:
			printf("board_type: ");
			if ((flag = in_getnum(&num)) != DB_OK)
				return flag;
			if (num > 1) {
				fprintf(stderr, "WARNING: board types: 1 or 0\n");
				return -1;
			}
			list[row].board_type = num;
			break;

		default:
			printf("WARNING: invalid column\n");
			return 0;
	}

	return DB_OK;
}

int db_del_row(int row)
{
	int flag;
	if ((flag = check_row(row)) != DB_OK)
		return flag;

	list[row].mark = FREE;
	row_count--;
	return DB_OK;
}


/* !! Cannot handle `or' bound operator  */
/*
SELECT * FROM table WHERE 
- name = newname and number < 324 or size > 100
- number = 1
*/
int db_query()
{
	char query[MAX_NAME_LENGTH], *p = query;

	/* get query string */
	printf("[*] SELECT * FROM TABLE ");
	in_getstr(p);

	/* send query string for parsing */
	struct param_t param[6];
	memset(param, 0, sizeof(param));
	qry_parse_query(p, param);


	/* perform query */
	return qry_run_query(param, row_count);
}

int db_show_table()
{
	if (row_count == 0)
		return DB_OK;

	/* name size is 15 */
	printf("NAME            NUMBER      SIZE        CAPAC       BTYPE  ATYPE\n");
	for (int i = 0; i < row_count; i++)
		db_show_row(i);

	return DB_OK;
}

int db_show_row(int i)
{
	char number[15],
		 size[15],
		 capacity[15],
		 board_type[2],
		 audit_type[2];

	sprintf(number, "%d", list[i].number);
	sprintf(size, "%d", list[i].size);
	sprintf(capacity, "%d", list[i].capacity);
	sprintf(board_type, "%d", list[i].board_type);
	sprintf(audit_type, "%d", list[i].audit_type);

	printf("%-*s %-*s %-*s %-*s %-*s %-*s\n", 
		15, list[i].name,
		11, number,
		11, size,
		11, capacity,
		6, audit_type,
		2, board_type);

	return 0;
}


int func1()
{

	setlocale(LC_ALL, "ru-RU");

	char s[40];
	int num1, num2;
	
	printf("Enter string: ");
	scanf("%s", s);
	printf("[%s]\n", s);

	printf("Enter number: ");
	scanf("%d", &num1);
	printf("[%d]\n", num1);

	printf("Enter number: ");
	scanf("%d", &num2);
	printf("[%d]\n", num2);

	printf("Enter number: ");
	scanf("%d", &num2);
	printf("[%d]\n", num2);

	return 0;
}


int func()
{
	char s1[10] = "hyuga";
	char s2[10] = "str";
	int num1 = 123;
	int num2 = 1;


	printf("[%-*s] [%*d]\n", 10, s1, 
							  4, num1);

	printf("[%-*s] [%*d]\n", 10, s2, 
							  4, num2);


    return 0; 
}



int db_interface()
{
	printf("1. Add new row\n");
	printf("2. Change row\n");
	printf("3. Delete row\n");
	printf("4. Make query\n");
	printf("5. Show table\n");
	printf("0. Exit\n");



	int cmd, flag, row;
	//return func();

	db_init();
	while (1) {
		printf("\n> ");
		if ((flag = in_getnum(&cmd)) != DB_OK)
			return flag;

		switch (cmd){
			case 1:
				flag = db_add_row(row);
				break;

			case 2:
				printf("row: ");
				if ((flag = in_getnum(&row)) != DB_OK)
					return flag;

				flag = db_chg_row(row);
				break;

			case 3:
				printf("row: ");
				if ((flag = in_getnum(&row)) != DB_OK)
					return flag;

				flag = db_del_row(row);
				break;

			case 4:
				flag = db_query();
				break;

			case 5:
				flag = db_show_table(row);
				break;

			case 0:
				/* exit */
				return 0;

			default:
				flag = DB_INVALID_CMD;
				break;
		}

		/* Handing return flag value */
		error_handling(flag);
	} 
}













