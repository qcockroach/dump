Personal suggestions:
	1) Install IDE Sublime Text 3 https://www.sublimetext.com/3
		It's the best graphical IDE for linix system

How to build:
	make init	=> make nesessery directories like lib, obj
	make build  => build dynamic library and compile it with main program
	make clean  => clean directory

How to run program:
	Usage: cockroach <libname> [FUNCNAME]...
	./cockroach lib/libfoo.so func1
	./cockroach lib/libfoo.so func2 func2
