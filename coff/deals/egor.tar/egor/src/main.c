#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>   // stat
#include <stdbool.h>    // bool type
#include "foo.h"

/* Notes

	That article should help you if U know english, of cource.
	https://www.cprogramming.com/tutorial/shared-libraries-linux-gcc.html

	This code works only on Unix like OS. On Windows system you have to
	install cygwin or similar program that'll provide Unix environment.
	
	Good luck, student.
 */


/* Функции, которые находятся в динамической библиотеке*/
static char *func_names[] = {
	"func1",
	"func2",
	"func3",
	"func4"
};

/* Указатели на те самые функции */
static int (*func_ptr[])() = { func1, func2, func3, func4 };
/* Переменная, сколько всего функции в динамической библиотеке*/
static int func_count = sizeof(func_names) / sizeof(func_names[0]);


void usage(void) {
	printf("Usage: cockroach <libname> [FUNCNAME]...\n");
}

/* Проверяет существует ли библиотека */
bool file_exists (char *filename) {
	struct stat   buffer;
	return (stat (filename, &buffer) == 0);
}

int main(int argc, char *argv[])
{
	int i, j;

	/* Проверяет добавлил ли ты библиотеку в командной строке  */
	if (argc < 2) {
		usage();
		return 0;
	}

	/* 	Если ты добавил библиотеку, то 
		проверяет существует ли библиотека 
	*/
	else {
		if (file_exists(argv[1]) == false) {
			fprintf(stderr, "[!] Error: library %s doesn't exist\n", argv[1]);
			return 1;
		} else
			printf("[+] Library name: %s\n", argv[1]);
	}

	/* Проверяет существуют ли вызываемые функции */
	printf("[+] Call functions...\n\n");
	for (i = 2; i < argc; i++) {
		for (j = 0; j < func_count; j++) {
			if (strcmp(func_names[j], argv[i]) == 0)
				break;
		}
		/* если несущ. то выводит ошибку */
		if (j == func_count) {
			fprintf(stderr, "[!] Error: function name [%s] not found\n", argv[i]);
			return 1;
		}

		/* И, наконецто, вызов каждой из функций */
		(*func_ptr[j])();
	}

	return 0;
}
