#include <stdio.h>
#include "foo.h"
 
int func1(void)
{
	printf("[1] Func1\n");
	return 0;
}

int func2(void)
{
	printf("[2] Func2\n");
	return 0;
}

int func3(void)
{
	printf("[3] Func3\n");
	return 0;
}

int func4(void)
{
	printf("[4] Func4\n");
	return 0;
}
