#ifndef __LIBFOO_H
# define __LIBFOO_H

/* 	extern - означает что функции 
	определена в одном из файлов или библиотеке.
 */

extern int func1(void);
extern int func2(void);
extern int func3(void);
extern int func4(void);

#endif