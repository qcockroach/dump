#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "btree.h"   /* API for binary tree  */
#include "bstruct.h" /* util to struuct BST correctly  */
#include "bview.h"   /* to view tree content  */

/* 
    Основные команды которые можно совершить над бинарным деревом
        - вставить
        - удалить
        - найти ключ
        - найти мин
     и т.д.
 */


/* При добавлении нового ключа в бинарное дерево поиска
    процесс начинается сверху. Если ключ больше или равно идем в право,
    иначе на лево.
*/
bnode_t *btree_insert (bnode_t *node, int key, char *val)
{
    /* If key is in tree already riase an error.  */
    bnode_t *tmpnode = btree_search (node, key);
    if (tmpnode != NULL && tmpnode->key == key) {
        fprintf (stderr, "[!] Error: key %d is already in tree\n", key);
        return NULL;
    }

    if (node == NULL) {
        return new_node (key, val);
    }

    if (key > node->key) {
        node->right = btree_insert (node->right, key, val);
    }
    else {
        node->left = btree_insert (node->left, key, val);
    }

    return node;
}

/* Поиск интересуемого ключа. */
bnode_t *btree_search (bnode_t *node, int key)
{
    // Base Cases: node is null or key is present at node
    if (node == NULL || node->key == key)
       return node;

    // Key is greater than node's key
    if (node->key < key)
       return btree_search(node->right, key);

    // Key is smaller than node's key
    return btree_search(node->left, key);
}


/* Чтобы удалить ключ нужно найти сначала ключ с самым маленьким значение,
    поставить его на самый вверх и только после удалить.
    Таким образом структура бинарного дерева поиска (BST) не нарушится.
*/
bnode_t *btree_delete (bnode_t *root, int key)
{
    // base case
    if (root == NULL)
        return root;

    // If the key to be deleted
    // is smaller than the root's
    // key, then it lies in left subtree
    if (key < root->key)
        root->left = btree_delete(root->left, key);

    // If the key to be deleted
    // is greater than the root's
    // key, then it lies in right subtree
    else if (key > root->key)
        root->right = btree_delete(root->right, key);

    // if key is same as root's key,
    // then This is the node
    // to be deleted
    else {
        // node with only one child or no child
        if (root->left == NULL) {
            bnode_t *temp = root->right;
            free_node(root);
            return temp;
        }
        else if (root->right == NULL) {
            bnode_t *temp = root->left;
            free_node(root);
            return temp;
        }

        // node with two children:
        // Get the inorder successor
        // (smallest in the right subtree)
        bnode_t *temp = btree_min(root->right);

        // Copy the inorder
        // successor's content to this node
        root->key = temp->key;

        // Delete the inorder successor
        root->right = btree_delete(root->right, temp->key);
    }

    return root;
}

bnode_t *btree_min(bnode_t* node)
{
    bnode_t* current = node;
 
    /* loop down to find the leftmost leaf */
    while (current && current->left != NULL)
        current = current->left;
 
    return current;
}


/* Показать бинарное дерево.
    1,2,3 - показывают ключ и значение как в таблице
    4     - показывает в виде графика
 */
int btree_show (bnode_t *node, int mode)
{
    int out = 0;

    switch (mode) {
    case 1:
        show_preorder (node);
        break;
    case 2:
        show_inorder (node);
        break;
    case 3:
        show_postorder (node);
        break;
    case 4:
        show_ascii (node);
        break;
    default:
        fprintf (stderr, "[!] Error: incorrect show mode `%d'\n", mode);
        out = 1;
    }

    return out;
}
