#ifndef __BTREE_H
#define __BTREE_H

#include "bstruct.h"

bnode_t *btree_insert (bnode_t *node, int key, char *val);
bnode_t *btree_search (bnode_t *root, int key);
bnode_t *btree_delete (bnode_t *root, int key);
bnode_t *btree_max (bnode_t *root);
bnode_t *btree_min(bnode_t* node);
bnode_t *btree_download (void);
int btree_show (bnode_t *node, int mode);
int btree_upload (bnode_t *root);

#endif
