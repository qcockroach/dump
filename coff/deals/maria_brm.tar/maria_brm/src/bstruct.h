#ifndef __BTREE_STRUCT
#define __BTREE_STRUCT

#define BTREE_FNAME     "btree.txt" /* Where save binary tree data to */
#define MAX_NODES       1024        /* Max size of binary tree */
#define MAX_LINE        1024        /* Max size of input line */

typedef struct bnode_t
{
	int coeff;
	int key;
	char *val;
	struct bnode_t *left;
	struct bnode_t *right;
} bnode_t;

/* Balance binary tree each time you insert node into binary seach tree.  */
bnode_t *btree_balance (bnode_t *node);

bnode_t *new_node (int key, char *val);
int free_node (bnode_t *node);

#endif
