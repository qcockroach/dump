#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "btree.h"
#include "bview.h"


/*
    Здесь реализованиы интрефейсы для команд как 
    - добавить
    - удалить
    - найти
    - загрузить из файла
    и т.д.
Тут все наглядно. Попробуй просто прочесть код.
*/

static bnode_t *root;

const char *cmds[][2] = {
    { "ins", "insert new node into binary tree" },
    { "del", "delete node from binary tree" },
    { "srch", "search key in binary tree" },
    { "show", "show keys and elements of binary tree" },
    { "min", "show minimum node of binary tree" },

    { "dwld", "download binary tree data from file" },
    { "help", "show this message" },
    { "quit", "quit from program" }
};


static int check_key (char *buff)
{
    while (*buff && *buff != '\n') {
        if (isdigit (*buff++) == 0) {
            return 1;
        }
    }
    return 0;
}

static int get_cmds (char *cmd)
{
    int size = sizeof (cmds) / sizeof (cmds[0]);

    for (int i = 0; i < size; ++i) {
        if (strcmp (cmds[i][0], cmd) == 0) {
            return i;
        }
    }
    return -1;
}

/* Добавить новый элемнет. */
int menu_insert (void)
{
    int key;
    char buff[1024];

    printf ("Enter node's key: ");
    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        if (check_key (buff) != 0) {
            fprintf (stderr, "[!] Warning: you have to enter ONLY positive key value\n");
            return 1;
        }
        key = atoi (buff);
        // printf ("> [%d]\n", key);
    }

    printf ("Enter node's value: ");
    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        buff[strlen(buff) - 1] = '\0';
        // printf ("[%s]\n", buff);
    }

    root = btree_insert (root, key, strdup (buff));

    /* Balance BST to convert into Perfect Binary Tree.  */
    root = btree_balance (root);
    return 0;
}

/* Добавить выбранный элемнет. */
int menu_delete (void)
{
    int key;
    char buff[1024];

    printf ("btree's key: ");
    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        if (check_key (buff) != 0) {
            fprintf (stderr, "[!] Warning: you have to enter ONLY positive key value\n");
            return 1;
        }
        key = atoi (buff);
    }

    root = btree_delete (root, key);

    /* Balance BST to convert into Perfect Binary Tree.  */
    root = btree_balance (root);
    return 0;
}

/* Найти выбранный элемнет. */
int menu_search (void)
{
    int key;
    char buff[1024];
    bnode_t *tmpnode = NULL;

    printf ("btree's key: ");
    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        if (check_key (buff) != 0) {
            fprintf (stderr, "[!] Warning: you have to enter ONLY positive key value\n");
            return 1;
        }
        key = atoi (buff);
    }

    tmpnode = btree_search (root, key);
    if (tmpnode != NULL) {
        printf("%d key's value: [%s]\n", key, root->val);
    }
    else {
        printf ("There's no key `%d'\n", key);
    }
    return 0;
}

/* Показать содержимое дерева. */
int menu_show (void)
{
    int mode;
    char buff[1024];

    printf ("mode: ");

    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        if (check_key (buff) != 0) {
            fprintf (stderr, "[!] Warning: you have to enter ONLY positive mode\n");
            return 1;
        }
        mode = atoi (buff);
    }

    /* show traversal mode.  */
    switch (mode) {
    case 1:
        printf ("mode: preorder\n");
        break;
    case 2:
        printf ("mode: inorder\n");
        break;
    case 3:
        printf ("mode: postorder\n");
        break;
    case 4:
        printf ("mode: ascii\n");
        break;
    }

    btree_show (root, mode);
    return 0;
}

/* Найти минимальный ключ */
int menu_min (void)
{
    bnode_t *minnode = btree_min (root);
    printf ("min key: %d", minnode->key);
    return 0;
}

/* Загрузить ключи и строки из файла.  */
int menu_download (void)
{
    root = btree_download ();
    return 0;
}

int menu_help (void)
{
    size_t size = sizeof (cmds) / sizeof (cmds[0]);

    printf ("btree operations\n");
    for (int i = 0; i < size; ++i) {
        printf ("  %s\t  %s\n", cmds[i][0], cmds[i][1]);
    }

    return 0;
}

/* Завершить программу.  */
int menu_quit (void)
{
    exit (EXIT_SUCCESS);
}

/* Это массив из функций.
    Выбираешь нужный и функция запускается.
 */
int (*menu_funcs[]) (void) = {
    & menu_insert,
    & menu_delete,
    & menu_search,
    & menu_show,
    & menu_min,
    & menu_download,
    & menu_help,
    & menu_quit,
};


int main (int argc, const char **argv)
{
    int cmd;
    char buff[1024];

    while (1) {
        printf ("> ");

        if (fgets (buff, sizeof (buff), stdin) != NULL) {
            buff[strlen(buff) - 1] = '\0';

            if ((cmd = get_cmds (buff)) == -1) {
                if (strlen (buff) == 0) {
                    continue;
                }
                fprintf (stderr, "[!] ERROR: command `%s' not found. Use `help' for more info\n", buff);
                continue ;
            }
        }

        /* perform btree operation.  */
        menu_funcs[cmd] ();
        printf ("\n");
    }

    return 0;
}
