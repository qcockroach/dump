#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include "btree.h"
#include "bstruct.h"

/* 
    Здесь необходимые функции чтобы 
    - построить бинарное дерево
    - скачать дынные из файла
    - сбалансировать
 */

static bnode_t *arrnode[MAX_NODES];
static int idx = 0;

/* utils to create and delete nodes.  */
/* Создать новый узел и ссылки на правый/левый узлы */
bnode_t *new_node (int key, char *val)
{
    bnode_t *node = malloc (sizeof (bnode_t));
    if (node == NULL) {
        return NULL;
    }
    node->coeff = 0;
    node->key = key;
    node->val = strdup (val);
    node->left = NULL;
    node->right = NULL;
    return node;
}

/* Освободить память для узла и строки при удалении.  */
int free_node (bnode_t *node)
{
    if (node == NULL) {
        return 0;
    }

    free (node->val);
    free (node);
    node = NULL;
    return 0;
}

/* Util for parsing input data.  */
/* Проверить является ли клю положительным и без букв.  */
static int check_key (char *buff)
{
    while (*buff && *buff != '\n') {
        if (isdigit (*buff++) == 0) {
            return 1;
        }
    }
    return 0;
}

/* Utils to download & upload binary tree content.  */
/* Временно сохранить дерево как массив (линейно). 
    Используется когда загружает данные из файла
*/
static int copy_arrnodes (int key, char *val)
{
    arrnode[idx] = new_node (key, strdup (val));
    if (arrnode[idx] == NULL) {
        perror ("copy_arrnodes");
        return 1;
    }
    idx++;
    return 0;
}

/* Удалить массив из узлов */
static int clean_arrnodes (void)
{
    for (int i = 0; i < idx; ++i) {
        arrnode[i] = NULL;
    }
    idx = 0;
    return 0;
}

/* utils for balancing BST.  */
/* Временно сохранить дерево как массив (линейно). */
static int store_nodes (bnode_t *node)
{
    /* Base case.  */
    if (node == NULL) {
        return 1;
    }

    /* Store nodes in Inorder (which is sorted order for BST) */
    store_nodes (node->left);

    /* Copy tree node into array for further balancing.  */
    arrnode[idx++] = node;
    store_nodes (node->right);

    return 0;
}

static bnode_t *build_btree_util (int start, int end)
{
    // base case
    if (start > end) {
        return NULL;
    }

    /* Get the middle element and make it root */
    int mid = (start + end)/2;
    bnode_t *root = arrnode[mid];

    /* Using index in Inorder traversal, construct left and right subtress */
    root->left = build_btree_util(start, mid-1);
    root->right = build_btree_util(mid+1, end);

    return root;
}

/* This functions converts an unbalanced BST to a balanced BST.  */
/* Сбалансиолвать дерево поиска (BST) после добавление/удаления */
bnode_t *btree_balance (bnode_t *node)
{
    store_nodes (node);
    bnode_t *tmp = build_btree_util (0, idx - 1);

    clean_arrnodes ();
    return tmp;
}

/* Скачать ключи и значения из файла */
bnode_t *btree_download (void)
{
    bnode_t *tmp = NULL;
    FILE *stream;
    char *line = NULL;
    size_t len = 0;
    ssize_t nread;
    int key;

    stream = fopen(BTREE_FNAME, "r");
    if (stream == NULL) {
       perror("btree_download");
       exit(EXIT_FAILURE);
    }

    while ((nread = getline(&line, &len, stream)) != -1) {

        if (check_key (line) != 0) {
            fprintf (stderr, "[!] Error: wrong key value. Check out your data file `%s'.\n", BTREE_FNAME);
            return NULL;
        }
        key = atoi (line);

        getline(&line, &len, stream);
        line[strlen (line) - 1] = 0;
        // printf ("[%d] [%s]\n", key, line);
        copy_arrnodes (key, line);
    }

    free(line);
    fclose(stream);

    /* build binary search tree.  */
    tmp = build_btree_util (0, idx - 1);

    clean_arrnodes ();
    return tmp;
}
