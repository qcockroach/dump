#ifndef __BTREE_VIEW
#define __BTREE_VIEW

#include "bstruct.h"

typedef struct asciinode_struct asciinode;

struct asciinode_struct
{
  asciinode * left, * right;
  int edge_length; 
  int height;      
  int lablen;
  int parent_dir;   
  char label[11];  
};


/* utils for to show binary tree content.  */
int show_preorder (bnode_t *node);
int show_inorder (bnode_t *node);
int show_postorder (bnode_t *node);
int show_ascii (bnode_t *node);

bnode_t * insert(int value, bnode_t * t);
bnode_t * delete(int value, bnode_t * t);

int MIN (int X, int Y);
int MAX (int X, int Y);

asciinode * build_ascii_tree_recursive(bnode_t * t);
asciinode * build_ascii_tree(bnode_t * t);
void free_ascii_tree(asciinode *node);
void compute_lprofile(asciinode *node, int x, int y);
void compute_rprofile(asciinode *node, int x, int y);
void compute_edge_lengths(asciinode *node);
void print_level(asciinode *node, int x, int level);
void print_ascii_tree(bnode_t * t);
int btree_view (void);

#endif
