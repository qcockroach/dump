#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "btree.h"


static bnode_t *root;


/* insert node into binary search tree */
int func_insert (void)
{
    char *val1 = strdup ("I am first line in binary search tree");
    char *val2 = strdup ("I am second line in binary search tree");
    char *val3 = strdup ("I am third line in binary search tree");
    char *val4 = strdup ("I am forth line in binary search tree");
    char *val5 = strdup ("I am fifth line in binary search tree");
    char *val6 = strdup ("I am sixth line in binary search tree");
    char *val7 = strdup ("I am seven-th line in binary search tree");
    char *val8 = strdup ("I am eight-th line in binary search tree");

    root = btree_insert (root, 1, val1);
    root = btree_insert (root, 2, val2);
    root = btree_insert (root, 3, val3);
    root = btree_insert (root, 4, val4);
    root = btree_insert (root, 5, val5);
    root = btree_insert (root, 6, val6);
    root = btree_insert (root, 7, val7);
    root = btree_insert (root, 8, val8);


    if (root == NULL) {
        fprintf (stderr, "!! Root empty\n");
        return 1;
    }

    return 0;
}

int func_search (void)
{
    if (root == NULL) {
        fprintf (stderr, "!! Root empty\n");
        return 1;
    }


    bnode_t *tmpnode = btree_search (root, 100);

    if (tmpnode == NULL) {
        printf ("> Root is empty\n");
    }
    else if (tmpnode->key == 1) {
        printf ("%d\n", tmpnode->key);
    }

    return 0;
}


int func_show (void)
{
    btree_show (root, 2);
    return 0;
}


int func_delete (void)
{
    int key = 4;

    if (root == NULL) {
        fprintf (stderr, "!! Root empty\n");
        return 1;
    }

    bnode_t *tmpnode = btree_search (root, key);

    if (tmpnode == NULL) {
        printf ("> key not found\n\n");
    }

    btree_delete (root, key);
    btree_delete (root, key + 1);
    return 0;
}


int func_balance (void)
{
    btree_show (root, 1);

    printf ("\nBinary search tree before balancing\n");
    btree_show (root, 3);

    root = btree_balance (root);

    printf ("\nBinary search tree after balancing\n");
    btree_show (root, 3);

    return 0;
}



static int check_key (char *buff)
{
    while (*buff && *buff != '\n') {
        if (isdigit (*buff++) == 0) {
            return 1;
        }
    }
    return 0;
}

const char *cmds[] = {
    "ins",
    "del",
    "srch",
    "show",
    "min",
    "quit",

/* not implemented yet.  */
    "upld",
    "dwld",
    "help"
};

static int get_cmds (char *cmd)
{
    int size = sizeof (cmds) / sizeof (cmds[0]);

    for (int i = 0; i < size; ++i) {
        if (strcmp (cmds[i], cmd) == 0) {
            return i;
        }
    }
    return -1;
}

int menu_insert (void)
{
    int key;
    char buff[1024];

    printf ("Enter positive key value: ");
    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        if (check_key (buff) != 0) {
            fprintf (stderr, "[!] Warning: you have to enter ONLY positive key value\n");
            return 1;
        }
        key = atoi (buff);
        printf ("> [%d]\n", key);
    }

    printf ("Enter string value: ");
    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        buff[strlen(buff) - 1] = '\0';
        printf ("[%s]\n", buff);
    }

/*    printf("ins key: %d\n", key);
    printf("ins val: %s\n", buff);*/
    root = btree_insert (root, key, strdup (buff));
    
    // printf (">> <<<\n");
    // btree_show (root, 1);
    // printf("9999999\n");

    return 0;
}

int menu_delete (void)
{
    int key;
    char buff[1024];

    printf ("btree's key: ");
    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        if (check_key (buff) != 0) {
            fprintf (stderr, "[!] Warning: you have to enter ONLY positive key value\n");
            return 1;
        }
        key = atoi (buff);
    }

    root = btree_delete (root, key);
    printf("del\n");
    return 0;
}

int menu_search (void)
{
    int key;
    char buff[1024];
    bnode_t *tmpnode = NULL;

    printf ("btree's key: ");
    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        if (check_key (buff) != 0) {
            fprintf (stderr, "[!] Warning: you have to enter ONLY positive key value\n");
            return 1;
        }
        key = atoi (buff);
    }

    tmpnode = btree_search (root, key);
    if (tmpnode != NULL) {
        printf("%d key's value: [%s]\n", key, root->val);
    }
    else {
        printf ("There's no key `%d'\n", key);
    }
    return 0;
}

int menu_show (void)
{
    int mode;
    char buff[1024];

    printf ("btree traversal mode: ");

    if (fgets (buff, sizeof (buff), stdin) != NULL) {
        if (check_key (buff) != 0) {
            fprintf (stderr, "[!] Warning: you have to enter ONLY positive mode\n");
            return 1;
        }
        mode = atoi (buff);
    }

    /* show traversal mode.  */
    switch (mode) {
    case 1:
        printf ("traversal mode: preorder\n");
        break;
    case 2:
        printf ("traversal mode: inorder\n");
        break;
    case 3:
        printf ("traversal mode: postorder\n");
        break;
    }

    btree_show (root, mode);
    return 0;
}

int menu_min (void)
{
    bnode_t *minnode = btree_min (root);
    printf ("min key: %d", minnode->key);
    return 0;
}

int menu_quit (void)
{
    printf("quit\n");
    exit (EXIT_SUCCESS);
}

int (*menu_funcs[]) (void) = {
    & menu_insert,
    & menu_delete,
    & menu_search,
    & menu_show,
    & menu_min,
    & menu_quit
};


int menu (int argc, const char **argv)
{
    int cmd;
    char buff[1024];

    printf ("-- BST util --\n");

    while (1) {
        printf ("> ");

        if (fgets (buff, sizeof (buff), stdin) != NULL) {
            buff[strlen(buff) - 1] = '\0';

            if ((cmd = get_cmds (buff)) == -1) {
                if (strlen (buff) == 0) {
                    continue;
                }
                fprintf (stderr, "[!] ERROR: command `%s' not found\n", buff);
                return 1;
            }
        }

        /* perform btree operation.  */
        menu_funcs[cmd] ();
    }

    return 0;
}


int main (int argc, const char **argv)
{
    func_insert ();
    func_show ();
    printf ("\n");
    func_delete ();
    func_show ();
    menu (argc, argv);

    return 0;
}
